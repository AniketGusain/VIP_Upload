package com.hexaware.VehicleInsuranceSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleInsuranceSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
