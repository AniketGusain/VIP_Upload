package com.hexaware.VehicleInsuranceSystem.models;

public enum Active {
    ACTIVE,
    INACTIVE
}
