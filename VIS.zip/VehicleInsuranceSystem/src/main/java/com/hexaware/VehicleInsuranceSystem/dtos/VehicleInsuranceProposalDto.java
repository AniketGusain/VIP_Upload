package com.hexaware.VehicleInsuranceSystem.dtos;


import com.hexaware.VehicleInsuranceSystem.models.ProposalStatus;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class VehicleInsuranceProposalDto {

    public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public VehicleInsuranceProposalDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VehicleInsuranceProposalDto(@NotNull(message = "User ID is required") Long userId,
			@NotNull(message = "Policy ID is required") Long policyId, ProposalStatus proposalStatus) {
		super();
		this.userId = userId;
		this.policyId = policyId;
		this.proposalStatus = proposalStatus;
	}

	public Long getPolicyId() {
		return policyId;
	}

	public void setPolicyId(Long policyId) {
		this.policyId = policyId;
	}

	public ProposalStatus getProposalStatus() {
		return proposalStatus;
	}

	public void setProposalStatus(ProposalStatus proposalStatus) {
		this.proposalStatus = proposalStatus;
	}

	@NotNull(message = "User ID is required")
    private Long userId;

    @NotNull(message = "Policy ID is required") // New field
    private Long policyId;

//    @NotEmpty(message = "Vehicle type is required")
//    private String vehicleType;
//
//    @NotEmpty(message = "Vehicle model is required")
//    private String vehicleModel;
//
//    private int vehicleYear;
//
//    @NotEmpty(message = "Vehicle VIN is required")
//    private String vehicleVin;
//
//    @NotEmpty(message = "Insurance coverage is required")
//    private String insuranceCoverage;

    private ProposalStatus proposalStatus;

//    private String additionalInfo;
//
//    private Date createdAt;

    // Getters and setters
}