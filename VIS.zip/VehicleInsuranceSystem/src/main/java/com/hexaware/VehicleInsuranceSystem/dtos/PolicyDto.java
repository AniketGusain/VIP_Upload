package com.hexaware.VehicleInsuranceSystem.dtos;
//import com.hexaware.VehicleInsuranceSystem.models.Active;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PolicyDto {

    private String policyName;
    private String policyDescription;
    public PolicyDto(String policyName, String policyDescription, String policyCompany, String companyDescription,
			boolean activePolicy, int claimsServed, int policyPrice) {
		super();
		this.policyName = policyName;
		this.policyDescription = policyDescription;
		this.policyCompany = policyCompany;
		this.companyDescription = companyDescription;
		this.activePolicy = activePolicy;
		this.claimsServed = claimsServed;
		this.policyPrice = policyPrice;
	}
	public PolicyDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String policyCompany;
    private String companyDescription;
    private boolean activePolicy;
    private int claimsServed;
    private int policyPrice;
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public String getPolicyDescription() {
		return policyDescription;
	}
	public void setPolicyDescription(String policyDescription) {
		this.policyDescription = policyDescription;
	}
	public String getPolicyCompany() {
		return policyCompany;
	}
	public void setPolicyCompany(String policyCompany) {
		this.policyCompany = policyCompany;
	}
	public String getCompanyDescription() {
		return companyDescription;
	}
	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}
	public boolean isActivePolicy() {
		return activePolicy;
	}
	public void setActivePolicy(boolean activePolicy) {
		this.activePolicy = activePolicy;
	}
	public int getClaimsServed() {
		return claimsServed;
	}
	public void setClaimsServed(int claimsServed) {
		this.claimsServed = claimsServed;
	}
	public int getPolicyPrice() {
		return policyPrice;
	}
	public void setPolicyPrice(int policyPrice) {
		this.policyPrice = policyPrice;
	}

}

