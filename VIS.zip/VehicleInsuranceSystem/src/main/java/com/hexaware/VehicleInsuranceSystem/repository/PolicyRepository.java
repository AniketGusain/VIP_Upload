package com.hexaware.VehicleInsuranceSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.VehicleInsuranceSystem.models.Policy;

public interface PolicyRepository extends JpaRepository<Policy, Long> {
}