package com.hexaware.VehicleInsuranceSystem.models;

public enum ProposalStatus {
    SUBMITTED,
    UNDER_REVIEW,
    APPROVED,
    REJECTED
}
